<?php

/** 
 *  The Wolfram Alpha Image Object
 *  @package WolframAlpha
 */
class WAImage {
  // define the sections of a response
  public $attributes = array();
 
  // Constructor
  public function WAImage () {
  }

}
?>

