<?php

/** 
 *  The Wolfram Alpha Subpod Object
 *  @package WolframAlpha
 */
class WASubpod {
  // define the sections of a response
  public $attributes = array();
  public $plaintext = '';
  public $image = '';
  public $minput = '';
  public $moutput = '';
  public $mathml = '';
 
  // Constructor
  public function WASubpod () {
  }

}
?>

