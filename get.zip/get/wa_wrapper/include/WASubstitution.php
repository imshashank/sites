<?php

/** 
 *  The Wolfram Alpha Substitution Object
 *  @package WolframAlpha
 */
class WASubstitution {
  // define the sections of a response
  public $name = '';
 
  // Constructor
  public function WASubstitution () {
  }

}
?>

