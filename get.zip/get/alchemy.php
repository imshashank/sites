<?php
require_once './alchemyapi_php/alchemyapi.php';
$alchemyapi = new AlchemyAPI();
$myText = "macbook pro";
$response = $alchemyapi->taxonomy("text", $myText, null);
var_dump($response);
$text= $response['taxonomy'][0]['label'];
$text = substr($text, 1);;
echo $text;
$pieces = explode('/', $text);
var_dump( $pieces);
?>
